const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const User = require("./models/User");

const app = express();
const PORT = process.env.PORT || 3003;

// Enable CORS for all routes
app.use(cors());
app.use(express.json());

// MongoDB connection
const MONGODB_URI =
  "mongodb+srv://admin:webdb@cluster0.xwckh9n.mongodb.net/web?retryWrites=true&w=majority";
mongoose
  .connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB:", err.message);
  });

// Define routes
app.get("/", (req, res) => {
  res.send("Hello, this is your Express server!");
});

app.post("/signup", async (req, res) => {
  const { first_name, last_name, email, phno, password, gender, dob } =
    req.body;
  console.log(req.body);
  //   try {
  const existingUser = await User.findOne({ email: email });
  if (existingUser) {
    return res.status(400).json({
      message: "User already exists with this email or phone number",
    });
  }
  const newUser = new User({
    first_name,
    last_name,
    email,
    phno,
    password,
    gender,
    dob,
  });

  await newUser.save();
  res.status(201).json({ message: "User created successfully" });
  //   } catch (error) {
  //     res
  //       .status(500)
  //       .json({ message: "Error signing up user", error: "Could not signUp" });
  //   }
});

app.post("/signin", async (req, res) => {
  const { email, password } = req.body;
  console.log(req.body);
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    const passwordMatch = password === user.password;
    if (!passwordMatch) {
      return res.status(401).json({
        message: "Invalid password",
        error: "Password is invalid",
      });
    }
    res.status(200).json({ message: "Sign in successful" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error signing in user", error: "Sign In Failed" });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
